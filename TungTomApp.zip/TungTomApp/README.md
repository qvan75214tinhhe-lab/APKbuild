# TungTom (APK)

App Android mở https://pokesurvivor.com/ bằng WebView, kèm tiện ích TungTom (bot + giảm lag).
Nút **ON / OFF** nằm ở app (kéo để dời): chỉ có tác dụng bật hoặc tắt tiện ích, không tải lại trang.

## Build bằng GitHub
1. Tạo repo mới trên GitHub, đẩy toàn bộ thư mục này lên (nhánh `main`).
2. Vào tab **Actions** -> workflow **Build APK** (tự chạy khi push, hoặc bấm *Run workflow*).
3. Chạy xong, mở lần chạy đó -> mục **Artifacts** -> tải **TungTom-apk** (giải nén ra file `app-debug.apk`).
4. Cài APK vào điện thoại (cho phép cài từ nguồn không rõ).

## Cập nhật tiện ích
Mã tiện ích nằm ở `app/src/main/assets/tungtom.js`. Sửa rồi push là Actions build lại APK.
