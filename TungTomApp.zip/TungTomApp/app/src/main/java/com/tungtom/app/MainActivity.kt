package com.tungtom.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlin.math.abs

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var toggle: TextView
    private lateinit var script: String

    // Chỉ trang pokesurvivor.com được nạp tiện ích; app làm đúng việc: nạp lớp khởi động (trơ) + bật / tắt theo nút
    private val origins = setOf("https://pokesurvivor.com", "https://www.pokesurvivor.com")
    private val homeUrl = "https://pokesurvivor.com/"

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        web = findViewById(R.id.web)
        toggle = findViewById(R.id.toggle)
        script = assets.open("tungtom.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.webChromeClient = WebChromeClient()

        // Nạp tiện ích TRƯỚC khi game chạy (cần để móc vào canvas / game); bản WebView cũ thì nạp ở onPageStarted
        val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (docStart) WebViewCompat.addDocumentStartJavaScript(web, script, origins)

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                // Mỗi lần tải trang mới: tiện ích ở trạng thái TẮT (không menu, không bot)
                setToggle(false)
                if (!docStart && url != null && origins.any { url.startsWith(it) }) {
                    view.evaluateJavascript(script, null)
                }
            }
        }

        // Kéo để dời nút, chạm nhanh để bật / tắt
        var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f; var moved = false
        toggle.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = v.x; startY = v.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (moved || abs(dx) + abs(dy) > 16) {
                        moved = true
                        val parent = v.parent as View
                        v.x = (startX + dx).coerceIn(0f, (parent.width - v.width).toFloat())
                        v.y = (startY + dy).coerceIn(0f, (parent.height - v.height).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleExtension()
                    true
                }
                else -> true
            }
        }

        if (savedInstanceState == null) web.loadUrl(homeUrl) else web.restoreState(savedInstanceState)
    }

    /** Bật nếu đang tắt, tắt nếu đang bật. Không tải lại trang. */
    private fun toggleExtension() {
        val js = "(function(){var t=window.__tungtom;if(!t)return 'missing';" +
            "if(t.isOn()){t.disable();return 'off';}t.enable();return 'on';})()"
        web.evaluateJavascript(js) { r ->
            when (r?.trim('"')) {
                "on" -> setToggle(true)
                "off" -> setToggle(false)
                else -> Toast.makeText(this, "Tiện ích chưa nạp xong, đợi trang tải rồi thử lại", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setToggle(on: Boolean) {
        toggle.text = if (on) "OFF" else "ON"
        toggle.setBackgroundResource(if (on) R.drawable.toggle_on else R.drawable.toggle_off)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
